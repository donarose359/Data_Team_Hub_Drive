# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 12:18:46 2024

@author: shrihari
"""

usr = 'hdol'
pwd = 'wwyzXqqh3aS2hFX'
auth_url = 'https://api.truckercloud.com/api/v4/authenticate'
carrier_url = 'https://api.truckercloud.com/api/v4/carriers'